﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestFilter;

namespace TestFilter
{
    public class VehicleDAL
    {


        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicleId"></param>
        /// <returns></returns>
        public static VehicleBO getVehicle(int vehicleId)
        {
            VehicleBO returnValue = null;
            

            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                IEnumerable<VehicleBO> vehicles = db.GetVehicle();
                if (vehicles.Count() > 0)
                {
                    returnValue = vehicles.First();
                }
            }

            return returnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicleId"></param>
        /// <param name="uui"></param>
        public static void deleteVehicle(VehicleBO vehicle)
        {
            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                //db.DeleteVehicle(
                //    vehicle.VehicleId,
                //    vehicle.Uui);
                // dont code anything here. It wont be used anyway
                db.SaveChanges();
            }
        }

        public static DateTime date_timespan(TimeSpan? ts)
        {
            DateTime dt = new DateTime(1900, 01, 01);

            TimeSpan? tsn = ts;
            if (tsn.HasValue)
            {
                dt = dt + tsn.Value;
            }

            return dt;
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicle"></param>
        public static int updateVehicle(VehicleBO vehicle)
        {
            int returnValue = -1;
            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                returnValue = db.UpdateVehicle(
                    vehicle.VehicleId,
                    vehicle.NumberPlate,
                    vehicle.WeightFrontAxel,
                    vehicle.CostsPerKm,
                    date_timespan(vehicle.Returntime)
                    );

                db.SaveChanges();
            }
            return returnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vehicle"></param>
        public static int insertVehicle(VehicleBO vehicle)
        {
            int? nId = -1;

            using (EntitiesModelTest db = new EntitiesModelTest())
            {
                db.InsertVehicle(
                    vehicle.NumberPlate,
                    vehicle.WeightFrontAxel,
                    vehicle.CostsPerKm, 
                    date_timespan(vehicle.Returntime),
                    ref nId
                );

                db.SaveChanges();
            }
            return nId.Value;
        }
    }
}
